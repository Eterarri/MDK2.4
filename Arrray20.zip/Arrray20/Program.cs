﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrray20
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Введите размер массива => ");
            int n = int.Parse(Console.ReadLine());
            double[] mass = new double[n];
            Console.WriteLine("Введите K => ");
            double k = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите L => ");
            double l = double.Parse(Console.ReadLine());
            double res = k+l;
            Console.WriteLine("Заполните массив : ");
            for (int i = 0; i < mass.Length; i++)
                mass[i] = double.Parse(Console.ReadLine());
            Console.WriteLine("Ваш массив => ");
            foreach (var item in mass)
                Console.Write(item + ";");

            Console.WriteLine();
            for (int i = 0; i < mass.Length; i++)
            {
                if (k <= mass[i] && mass[i]<=l)
                    res += mass[i];
            }

            Console.WriteLine($"Ваша сумм от K до L = {res}") ;
            Console.ReadKey();
        }
    }
}
