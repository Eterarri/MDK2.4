﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._135
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ваше время => ");
            int n = Math.Abs(int.Parse(Console.ReadLine()));
            int time = 0;
            string res = "";
            while (n >= time)
            {
                time += 3;
                if (n <= time)
                {
                    res = "зеленый";
                    break;
                }
                time += 1;
                if (n <= time)
                {
                    res = "желтый";
                    break;
                }
                time += 2;
                if (n <= time)
                {
                    res = "Красный";
                    break;
                }
            }
            Console.WriteLine("Сейчас горит => "+ res);
            Console.ReadKey();
        }
    }
}
