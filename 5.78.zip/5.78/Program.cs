﻿using System;

namespace _5._78
{
    class Program
    {
        static void Main(string[] args)
        {
            double s = 0; // Площадь                
            for (int i = 0; i < 9; i++)
            {
                //Math.PI / 10: основание триугл, i: x
                double y = Math.Sin((Math.PI / 10) * i);
                s += (Math.PI / 10) * y;
            }
            Console.WriteLine(s);
            Console.ReadKey();
        }
    }
}
