﻿using System;

namespace Series20
{
    class Program
    {
        static void Main()
        {           
            Console.WriteLine("Введите кол-во элементов");
            int index = int.Parse(Console.ReadLine());
            double[] mass = new double[index];
            for (int i = 0; i < mass.Length; i++)
                mass[i] = double.Parse(Console.ReadLine());
            Console.Write("Ваши элементы => ");
            foreach (var item in mass)
                Console.Write(item + ";");
            Console.WriteLine();
            Console.WriteLine("Введите число K => ");
            int k = int.Parse(Console.ReadLine());
            for (int i = 0; i < k; i++)
            {
                if (mass[i] < mass[i+1])
                    Console.WriteLine($"Число {mass[i+1]} > Числа {mass[i]}") ;              
            }
            Console.ReadKey();
        }
    }
}
