﻿using System;
using System.Linq;

namespace Minmax20
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = Console.ReadLine().Split(' ').Select(x => int.Parse(x)).ToArray();
            int result = (a.Min() + a.Max()) / 2;
            int countMax = 0;
            int countMin = 0;
            foreach (var item in a)
            {
                if (result <= item)
                    countMax++;
                else
                    countMin++;
            }
            Console.WriteLine($"Кол-во минимальных: {countMin}, кол-во максимальных: {countMax}");
            Console.ReadKey();
        }
    }
}
