﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While20
{
    class Program
    {
        static void Main()
        {
            Console.Write("Ваше число => ");
            int a = int.Parse(Console.ReadLine());
            while (a%10 != 2)
            {
                a /= 10;
                if (a <= 0)
                    break;
            }
            

            if (a%10 == 2)
                Console.WriteLine(true);
            else
                Console.WriteLine(false);
            Console.ReadKey();
        }
    }
}
