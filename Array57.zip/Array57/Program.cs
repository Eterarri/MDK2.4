﻿using System;
using System.Linq;

namespace Array57
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите массив => ");
            int[] numbers = Console.ReadLine().Split(' ').Select(x => int.Parse(x)).ToArray();
            int[] result = new int[numbers.Length];
            int count = 0;
            for (int i = 0; i < numbers.Length; i += 2)
            {
                result[count] = numbers[i];
                count++;
            }
            for (int i = 1; i < numbers.Length; i+=2)
            {
                result[count] = numbers[i];
                count++;
            }
            Console.Write("Ваш массив =>\t  ");
            Console.Write(string.Join(" ", result));
            Console.ReadKey();

        }
    }
}
