﻿using System;
namespace Array2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите размер => ");
            int a = int.Parse(Console.ReadLine());
            int[] mass = new int[a] ;
            for (int i = 0; i < mass.Length; i++)
                mass[i] = (int)Math.Pow(2, i);
            Console.WriteLine("Result: " + string.Join(" ",mass));
            Console.ReadKey();

        }
    }
}
