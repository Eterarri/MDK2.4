﻿using System;

namespace Boolean20
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Введите 3 числа.");
            double[] mass = new double[3];
            for (int i = 0; i < mass.Length; i++)
                mass[i] = double.Parse(Console.ReadLine());

            if (mass[0] != mass[1] && mass[0] !=mass[2] && mass[1] != mass[0] && mass[1] != mass[2]
                && mass[2] != mass[0] && mass[2] != mass[1])
                Console.WriteLine("Ваши числа разные");
            else
                Console.WriteLine("В ваших числах есть одинаковые элементы");
            Console.ReadKey();
            
        }

    }
}
